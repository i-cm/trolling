# The OmegaNum Tree changelog:
# v1.1 - 5/28/21
- Switched to OmegaNum
- Formatting improvements
- Updated to TMT v2.5.11

# v1.0 - 4/27/21
- Fixed a bug where progress didn't save
- Formatting improvements

# v0.1 - 4/26/21
- Converted the tree to ExpantaNum.
- Fixed NaNs