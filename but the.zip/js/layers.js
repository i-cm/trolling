addLayer("p", {
    name: "prestige", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "P", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 0, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() { return {
        unlocked: true,
		points: new ExpantaNum(0),
		resetTime: 0
    }},
    color: "#4BDC13",
    requires: new ExpantaNum(1), // Can be a function that takes requirement increases into account
    resource: "prestige points", // Name of prestige currency
    baseResource: "points", // Name of resource prestige is based on
    baseAmount() {return player.points}, // Get the current amount of baseResource
    type: "normal", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    exponent: 0.75, // Prestige currency exponent
    gainMult() { // Calculate the multiplier for main currency from bonuses
        mult = new ExpantaNum(1)
        return mult
    },
    gainExp() { // Calculate the exponent on main currency from bonuses
        return new ExpantaNum(1)
    },
    row: 0, // Row the layer is in on the tree (0 is the first row)
    hotkeys: [
        {key: "p", description: "P: Reset for prestige points", onPress(){if (canReset(this.layer)) doReset(this.layer)}},
    ],
    layerShown(){return true},
    upgrades: {
      11: {
        title: "Double",
        description: "Double points gain",
        cost: new ExpantaNum(5)
      },
      12: {
        title: "Double Again",
        description: "Double points gain",
        cost: new ExpantaNum(10),
        unlocked() {
          return hasUpgrade("p", 11)
        },
      },
      13: {
        title: "Triple",
        description: "Triple points gain",
        cost: new ExpantaNum(20),
        unlocked() {
          return hasUpgrade("p", 12)
        },
      },
      14: {
        title: "Triple Again",
        description: "Triple points gain",
        cost: new ExpantaNum(25),
        unlocked() {
          return hasUpgrade("p", 13)
        },
      },
      21: {
        title: "Synergy",
        description: "Points boost itself",
        cost: new ExpantaNum(100),
        unlocked() {
          return hasUpgrade("p", 14)
        },
        effect() {
          return player.points.add(10).log10().add(1)
        }
      },
      22: {
        title: "Point Time",
        description: "Boost points by reset time",
        cost: new ExpantaNum(500),
        unlocked() {
          return hasUpgrade("p", 21)
        },
        effect() {
          return player.p.resetTime + 1
        }
      },
      23: {
        title: "Prestige Boost",
        description: "Point gain is boosted by Prestige Points",
        cost: new ExpantaNum(2500),
        unlocked() {
          return hasUpgrade("p", 22)
        },
        effect() {
          return player.p.points.add(2).logBase(2).add(1)
        }
      },
      24: {
        title: "New Layer",
        description: "Unlock a new layer",
        cost: new ExpantaNum(25000),
        unlocked() {
          return hasUpgrade("p", 23)
        }
      },
      
    },
    prestigeNotify() {
      return getResetGain(this.layer).gte(player.p.points)
    }
})

addLayer("m", {
    name: "money", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "$", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 0, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() { return {
        unlocked: true,
		points: new ExpantaNum(0),
		resetTime: 0
    }},
    color: "#DCDC13",
    requires: new ExpantaNum(1), // Can be a function that takes requirement increases into account
    resource: "cash", // Name of prestige currency
    baseResource: "points", // Name of resource prestige is based on
    baseAmount() {return player.points}, // Get the current amount of baseResource
    type: "none", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    exponent: 0.75, // Prestige currency exponent
    gainMult() { // Calculate the multiplier for main currency from bonuses
        mult = new ExpantaNum(1)
        return mult
    },
    gainExp() { // Calculate the exponent on main currency from bonuses
        return new ExpantaNum(1)
    },
    row: 1, // Row the layer is in on the tree (0 is the first row)
    hotkeys: [
        {key: "r", description: "R: Reset for rebirth points", onPress(){if (canReset(this.layer)) doReset(this.layer)}},
    ],
    layerShown(){return hasUpgrade("p", 24)
    },
    upgrades: {
      11: {
        title: "Get a Job",
        description: "Start generating Cash",
        cost: new ExpantaNum(0)
      },
      12: {
        title: "Get a Better Job",
        description: "10x Cash gain",
        cost: new ExpantaNum(15),
        unlocked() {
          return hasUpgrade("m", 11)
        },
      },
      13: {
        title: "The Best job and you can't possibly go wrong with it",
        description: "F10x Cash gain",
        cost: new ExpantaNum(100),
        unlocked() {
          return hasUpgrade("m", 12)
        },
      },
      19: {
        title: "No more scam<sub>bonus #1</sub>",
        description: "Restore Cash gain",
        cost: new ExpantaNum(0),
        unlocked() {
          return hasUpgrade("m", 13)
        },
      },
      14: {
        title: "Get a Better Job than the scam one",
        description: "F100000000000x Cash gain",
        cost: new ExpantaNum(99),
        unlocked() {
          return hasUpgrade("m", 13)
        },
      },
      15: {
        title: "eyJ0YWIiOiJvcHRpb25zLXRhYiIsIm5hdlRhYiI6InRyZWUtdGFiIiwidGltZSI6MTcwMTE0Mzg0NTE1NCwibm90aWZ5Ijp7fSwidmVyc2lvblR5cGUiOiJsb2xpZHJ1ZHhiY3UiLCJ2ZXJzaW9uIjoieW91IGdvdCBsb2xkIiwidGltZVBsYXllZCI6NDIxLjkzODAwMDAwMDAzMjA1LCJrZWVwR29pbmciOmZhbHNlLCJoYXNOYU4iOmZhbHNlLCJwb2ludHMiOnsiYXJyYXkiOls5NTgzNjcwNy41NDkwNjc2NV0sInNpZ24iOjF9LCJzdWJ0YWJzIjp7ImNoYW5nZWxvZy10YWIiOnt9fSwibGFzdFNhZmVUYWIiOiJtIiwiaW5mb2JveGVzIjp7fSwiaW5mby10YWIiOnsidW5sb2NrZWQiOnRydWUsInRvdGFsIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJiZXN0Ijp7ImFycmF5IjpbbnVsbF0sInNpZ24iOjF9LCJyZXNldFRpbWUiOjQyMS45MzgwMDAwMDAwMzIwNSwiZm9yY2VUb29sdGlwIjpmYWxzZSwiYnV5YWJsZXMiOnt9LCJub1Jlc3BlY0NvbmZpcm0iOmZhbHNlLCJjbGlja2FibGVzIjp7fSwic3BlbnRPbkJ1eWFibGVzIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJ1cGdyYWRlcyI6W10sIm1pbGVzdG9uZXMiOltdLCJsYXN0TWlsZXN0b25lIjpudWxsLCJhY2hpZXZlbWVudHMiOltdLCJjaGFsbGVuZ2VzIjp7fSwiZ3JpZCI6e30sInByZXZUYWIiOiIifSwib3B0aW9ucy10YWIiOnsidW5sb2NrZWQiOnRydWUsInRvdGFsIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJiZXN0Ijp7ImFycmF5IjpbbnVsbF0sInNpZ24iOjF9LCJyZXNldFRpbWUiOjQyMS45MzgwMDAwMDAwMzIwNSwiZm9yY2VUb29sdGlwIjpmYWxzZSwiYnV5YWJsZXMiOnt9LCJub1Jlc3BlY0NvbmZpcm0iOmZhbHNlLCJjbGlja2FibGVzIjp7fSwic3BlbnRPbkJ1eWFibGVzIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJ1cGdyYWRlcyI6W10sIm1pbGVzdG9uZXMiOltdLCJsYXN0TWlsZXN0b25lIjpudWxsLCJhY2hpZXZlbWVudHMiOltdLCJjaGFsbGVuZ2VzIjp7fSwiZ3JpZCI6e30sInByZXZUYWIiOiIifSwiY2hhbmdlbG9nLXRhYiI6eyJ1bmxvY2tlZCI6dHJ1ZSwidG90YWwiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sImJlc3QiOnsiYXJyYXkiOltudWxsXSwic2lnbiI6MX0sInJlc2V0VGltZSI6NDIxLjkzODAwMDAwMDAzMjA1LCJmb3JjZVRvb2x0aXAiOmZhbHNlLCJidXlhYmxlcyI6e30sIm5vUmVzcGVjQ29uZmlybSI6ZmFsc2UsImNsaWNrYWJsZXMiOnt9LCJzcGVudE9uQnV5YWJsZXMiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sInVwZ3JhZGVzIjpbXSwibWlsZXN0b25lcyI6W10sImxhc3RNaWxlc3RvbmUiOm51bGwsImFjaGlldmVtZW50cyI6W10sImNoYWxsZW5nZXMiOnt9LCJncmlkIjp7fSwicHJldlRhYiI6IiJ9LCJibGFuayI6eyJ1bmxvY2tlZCI6dHJ1ZSwidG90YWwiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sImJlc3QiOnsiYXJyYXkiOltudWxsXSwic2lnbiI6MX0sInJlc2V0VGltZSI6NDIxLjkzODAwMDAwMDAzMjA1LCJmb3JjZVRvb2x0aXAiOmZhbHNlLCJidXlhYmxlcyI6e30sIm5vUmVzcGVjQ29uZmlybSI6ZmFsc2UsImNsaWNrYWJsZXMiOnt9LCJzcGVudE9uQnV5YWJsZXMiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sInVwZ3JhZGVzIjpbXSwibWlsZXN0b25lcyI6W10sImxhc3RNaWxlc3RvbmUiOm51bGwsImFjaGlldmVtZW50cyI6W10sImNoYWxsZW5nZXMiOnt9LCJncmlkIjp7fSwicHJldlRhYiI6IiJ9LCJ0cmVlLXRhYiI6eyJ1bmxvY2tlZCI6dHJ1ZSwidG90YWwiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sImJlc3QiOnsiYXJyYXkiOltudWxsXSwic2lnbiI6MX0sInJlc2V0VGltZSI6NDIxLjkzODAwMDAwMDAzMjA1LCJmb3JjZVRvb2x0aXAiOmZhbHNlLCJidXlhYmxlcyI6e30sIm5vUmVzcGVjQ29uZmlybSI6ZmFsc2UsImNsaWNrYWJsZXMiOnt9LCJzcGVudE9uQnV5YWJsZXMiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sInVwZ3JhZGVzIjpbXSwibWlsZXN0b25lcyI6W10sImxhc3RNaWxlc3RvbmUiOm51bGwsImFjaGlldmVtZW50cyI6W10sImNoYWxsZW5nZXMiOnt9LCJncmlkIjp7fSwicHJldlRhYiI6IiJ9LCJwIjp7InVubG9ja2VkIjp0cnVlLCJwb2ludHMiOnsiYXJyYXkiOlsyNTA1NTk1Nl0sInNpZ24iOjF9LCJyZXNldFRpbWUiOjUuODQ5OTk5OTk5OTk5OTk5LCJ0b3RhbCI6eyJhcnJheSI6WzI1MDg0MTE2XSwic2lnbiI6MX0sImJlc3QiOnsiYXJyYXkiOlsyNTA1NTk1Nl0sInNpZ24iOjF9LCJmb3JjZVRvb2x0aXAiOmZhbHNlLCJidXlhYmxlcyI6e30sIm5vUmVzcGVjQ29uZmlybSI6ZmFsc2UsImNsaWNrYWJsZXMiOnt9LCJzcGVudE9uQnV5YWJsZXMiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sInVwZ3JhZGVzIjpbMTEsMTIsMTMsMTQsMjEsMjIsMjMsMjRdLCJtaWxlc3RvbmVzIjpbXSwibGFzdE1pbGVzdG9uZSI6bnVsbCwiYWNoaWV2ZW1lbnRzIjpbXSwiY2hhbGxlbmdlcyI6e30sImdyaWQiOnt9LCJwcmV2VGFiIjoiIn0sIm0iOnsidW5sb2NrZWQiOnRydWUsInBvaW50cyI6eyJhcnJheSI6WzU3MS4zOTYxNjYxMzk0NTI1XSwic2lnbiI6MX0sInJlc2V0VGltZSI6MjY3LjE1NTAwMDAwMDAxMzg0LCJ0b3RhbCI6eyJhcnJheSI6WzBdLCJzaWduIjoxfSwiYmVzdCI6eyJhcnJheSI6WzBdLCJzaWduIjoxfSwiZm9yY2VUb29sdGlwIjpmYWxzZSwiYnV5YWJsZXMiOnt9LCJub1Jlc3BlY0NvbmZpcm0iOmZhbHNlLCJjbGlja2FibGVzIjp7fSwic3BlbnRPbkJ1eWFibGVzIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJ1cGdyYWRlcyI6WzExLDEyLDEzLDE5XSwibWlsZXN0b25lcyI6W10sImxhc3RNaWxlc3RvbmUiOm51bGwsImFjaGlldmVtZW50cyI6W10sImNoYWxsZW5nZXMiOnt9LCJncmlkIjp7fSwicHJldlRhYiI6IiJ9fQ==",
        description: "eyJ0YWIiOiJvcHRpb25zLXRhYiIsIm5hdlRhYiI6InRyZWUtdGFiIiwidGltZSI6MTcwMTE0Mzg0NTE1NCwibm90aWZ5Ijp7fSwidmVyc2lvblR5cGUiOiJsb2xpZHJ1ZHhiY3UiLCJ2ZXJzaW9uIjoieW91IGdvdCBsb2xkIiwidGltZVBsYXllZCI6NDIxLjkzODAwMDAwMDAzMjA1LCJrZWVwR29pbmciOmZhbHNlLCJoYXNOYU4iOmZhbHNlLCJwb2ludHMiOnsiYXJyYXkiOls5NTgzNjcwNy41NDkwNjc2NV0sInNpZ24iOjF9LCJzdWJ0YWJzIjp7ImNoYW5nZWxvZy10YWIiOnt9fSwibGFzdFNhZmVUYWIiOiJtIiwiaW5mb2JveGVzIjp7fSwiaW5mby10YWIiOnsidW5sb2NrZWQiOnRydWUsInRvdGFsIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJiZXN0Ijp7ImFycmF5IjpbbnVsbF0sInNpZ24iOjF9LCJyZXNldFRpbWUiOjQyMS45MzgwMDAwMDAwMzIwNSwiZm9yY2VUb29sdGlwIjpmYWxzZSwiYnV5YWJsZXMiOnt9LCJub1Jlc3BlY0NvbmZpcm0iOmZhbHNlLCJjbGlja2FibGVzIjp7fSwic3BlbnRPbkJ1eWFibGVzIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJ1cGdyYWRlcyI6W10sIm1pbGVzdG9uZXMiOltdLCJsYXN0TWlsZXN0b25lIjpudWxsLCJhY2hpZXZlbWVudHMiOltdLCJjaGFsbGVuZ2VzIjp7fSwiZ3JpZCI6e30sInByZXZUYWIiOiIifSwib3B0aW9ucy10YWIiOnsidW5sb2NrZWQiOnRydWUsInRvdGFsIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJiZXN0Ijp7ImFycmF5IjpbbnVsbF0sInNpZ24iOjF9LCJyZXNldFRpbWUiOjQyMS45MzgwMDAwMDAwMzIwNSwiZm9yY2VUb29sdGlwIjpmYWxzZSwiYnV5YWJsZXMiOnt9LCJub1Jlc3BlY0NvbmZpcm0iOmZhbHNlLCJjbGlja2FibGVzIjp7fSwic3BlbnRPbkJ1eWFibGVzIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJ1cGdyYWRlcyI6W10sIm1pbGVzdG9uZXMiOltdLCJsYXN0TWlsZXN0b25lIjpudWxsLCJhY2hpZXZlbWVudHMiOltdLCJjaGFsbGVuZ2VzIjp7fSwiZ3JpZCI6e30sInByZXZUYWIiOiIifSwiY2hhbmdlbG9nLXRhYiI6eyJ1bmxvY2tlZCI6dHJ1ZSwidG90YWwiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sImJlc3QiOnsiYXJyYXkiOltudWxsXSwic2lnbiI6MX0sInJlc2V0VGltZSI6NDIxLjkzODAwMDAwMDAzMjA1LCJmb3JjZVRvb2x0aXAiOmZhbHNlLCJidXlhYmxlcyI6e30sIm5vUmVzcGVjQ29uZmlybSI6ZmFsc2UsImNsaWNrYWJsZXMiOnt9LCJzcGVudE9uQnV5YWJsZXMiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sInVwZ3JhZGVzIjpbXSwibWlsZXN0b25lcyI6W10sImxhc3RNaWxlc3RvbmUiOm51bGwsImFjaGlldmVtZW50cyI6W10sImNoYWxsZW5nZXMiOnt9LCJncmlkIjp7fSwicHJldlRhYiI6IiJ9LCJibGFuayI6eyJ1bmxvY2tlZCI6dHJ1ZSwidG90YWwiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sImJlc3QiOnsiYXJyYXkiOltudWxsXSwic2lnbiI6MX0sInJlc2V0VGltZSI6NDIxLjkzODAwMDAwMDAzMjA1LCJmb3JjZVRvb2x0aXAiOmZhbHNlLCJidXlhYmxlcyI6e30sIm5vUmVzcGVjQ29uZmlybSI6ZmFsc2UsImNsaWNrYWJsZXMiOnt9LCJzcGVudE9uQnV5YWJsZXMiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sInVwZ3JhZGVzIjpbXSwibWlsZXN0b25lcyI6W10sImxhc3RNaWxlc3RvbmUiOm51bGwsImFjaGlldmVtZW50cyI6W10sImNoYWxsZW5nZXMiOnt9LCJncmlkIjp7fSwicHJldlRhYiI6IiJ9LCJ0cmVlLXRhYiI6eyJ1bmxvY2tlZCI6dHJ1ZSwidG90YWwiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sImJlc3QiOnsiYXJyYXkiOltudWxsXSwic2lnbiI6MX0sInJlc2V0VGltZSI6NDIxLjkzODAwMDAwMDAzMjA1LCJmb3JjZVRvb2x0aXAiOmZhbHNlLCJidXlhYmxlcyI6e30sIm5vUmVzcGVjQ29uZmlybSI6ZmFsc2UsImNsaWNrYWJsZXMiOnt9LCJzcGVudE9uQnV5YWJsZXMiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sInVwZ3JhZGVzIjpbXSwibWlsZXN0b25lcyI6W10sImxhc3RNaWxlc3RvbmUiOm51bGwsImFjaGlldmVtZW50cyI6W10sImNoYWxsZW5nZXMiOnt9LCJncmlkIjp7fSwicHJldlRhYiI6IiJ9LCJwIjp7InVubG9ja2VkIjp0cnVlLCJwb2ludHMiOnsiYXJyYXkiOlsyNTA1NTk1Nl0sInNpZ24iOjF9LCJyZXNldFRpbWUiOjUuODQ5OTk5OTk5OTk5OTk5LCJ0b3RhbCI6eyJhcnJheSI6WzI1MDg0MTE2XSwic2lnbiI6MX0sImJlc3QiOnsiYXJyYXkiOlsyNTA1NTk1Nl0sInNpZ24iOjF9LCJmb3JjZVRvb2x0aXAiOmZhbHNlLCJidXlhYmxlcyI6e30sIm5vUmVzcGVjQ29uZmlybSI6ZmFsc2UsImNsaWNrYWJsZXMiOnt9LCJzcGVudE9uQnV5YWJsZXMiOnsiYXJyYXkiOlswXSwic2lnbiI6MX0sInVwZ3JhZGVzIjpbMTEsMTIsMTMsMTQsMjEsMjIsMjMsMjRdLCJtaWxlc3RvbmVzIjpbXSwibGFzdE1pbGVzdG9uZSI6bnVsbCwiYWNoaWV2ZW1lbnRzIjpbXSwiY2hhbGxlbmdlcyI6e30sImdyaWQiOnt9LCJwcmV2VGFiIjoiIn0sIm0iOnsidW5sb2NrZWQiOnRydWUsInBvaW50cyI6eyJhcnJheSI6WzU3MS4zOTYxNjYxMzk0NTI1XSwic2lnbiI6MX0sInJlc2V0VGltZSI6MjY3LjE1NTAwMDAwMDAxMzg0LCJ0b3RhbCI6eyJhcnJheSI6WzBdLCJzaWduIjoxfSwiYmVzdCI6eyJhcnJheSI6WzBdLCJzaWduIjoxfSwiZm9yY2VUb29sdGlwIjpmYWxzZSwiYnV5YWJsZXMiOnt9LCJub1Jlc3BlY0NvbmZpcm0iOmZhbHNlLCJjbGlja2FibGVzIjp7fSwic3BlbnRPbkJ1eWFibGVzIjp7ImFycmF5IjpbMF0sInNpZ24iOjF9LCJ1cGdyYWRlcyI6WzExLDEyLDEzLDE5XSwibWlsZXN0b25lcyI6W10sImxhc3RNaWxlc3RvbmUiOm51bGwsImFjaGlldmVtZW50cyI6W10sImNoYWxsZW5nZXMiOnt9LCJncmlkIjp7fSwicHJldlRhYiI6IiJ9fQ==",
        cost: new ExpantaNum(0),
        unlocked() {
          return hasUpgrade("m", 14)
        },
      },
      16: {
        title: "Not a scam",
        description: "^9999999 Cash and scam gain",
        cost: new ExpantaNum(15),
        unlocked() {
          return hasUpgrade("m", 15)
        },
      },
      
    },
    branches: ["p"],
    update() {
      player.m.points = player.m.points.add(getMoneyGen().div(30).div(player.m.points.add(10).log10().add(1)))
    }
})

addLayer("s", {
    name: "antivirus", // This is optional, only used in a few places, If absent it just uses the layer id.
    symbol: "🛡️", // This appears on the layer's node. Default is the id with the first letter capitalized
    position: 0, // Horizontal position within a row. By default it uses the layer id and sorts in alphabetical order
    startData() { return {
        unlocked: true,
		points: new ExpantaNum(0),
		resetTime: 0
    }},
    color: "#696969",
    requires: new ExpantaNum(1e99), // Can be a function that takes requirement increases into account
    resource: "antivirus points", // Name of prestige currency
    baseResource: "BiaryMSM haters", // Name of resource prestige is based on
    baseAmount() {return player.points}, // Get the current amount of baseResource
    type: "static", // normal: cost to gain currency depends on amount gained. static: cost depends on how much you already have
    exponent: 0.00000000000000000000000001, // Prestige currency exponent
    gainMult() { // Calculate the multiplier for main currency from bonuses
        mult = new ExpantaNum(1)
        return mult
    },
    gainExp() { // Calculate the exponent on main currency from bonuses
        return new ExpantaNum(1)
    },
    row: 99, // Row the layer is in on the tree (0 is the first row)
    hotkeys: [
        {key: "alt+f4", description: "Press Alt+F4 to delete scams", onPress(){if (canReset(this.layer)) doReset(this.layer)}},
    ],
    layerShown(){return true},
    upgrades: {
      11: {
        title: "Scam protection",
        description: "Square Money Gain",
        cost: new ExpantaNum(1)
      },
      
      
    },
    prestigeNotify() {
      return getResetGain(this.layer).gte(player.p.points)
    },
    branches: ["p", "m"]
})